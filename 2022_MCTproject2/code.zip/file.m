% Turbo coded QPSK over AWGN - logMAP
close all
clear all
clc
%---------------- SIMULATION PARAMETERS ------------------------------------
SNR_dB = 0.5; % SNR per bit in dB (in logarithmic scale)
sim_runs = 1*(10^3); % simulation runs
frame_size = 2000; % frame size
num_bit = 0.5*frame_size; % number of data bits (overall rate is 1/2)
SNR = 10^(0.1*SNR_dB); % SNR per bit in linear scale
noise_var_1D = 2*2/(2*SNR); % 1D noise variance
%--------------------------------------------------------------------------
%    Generator polynomial of the component encoders
gen_poly = ldiv2([1 1 1 0 1],[1 1 0 0 1],num_bit); % using long division method
% [1 (1+D^2)/(1+D+D^2)]
%  Interleaver and deinterleaver mapping of the turbo code 
intr_map = randperm(num_bit);
deintr_map = deintrlv((1:num_bit),intr_map);

%--------------------------------------------------------------------------
C_Ber = 0; % channel errors
C_Ber1 = 0;
C_Ber2 = 0;
C_Ber3 = 0;
C_Ber4 = 0;
C_Ber5 = 0;
C_Ber6 = 0;
tic()
%--------------------------------------------------------------------------

for frame_cnt = 1:sim_runs

%                           TRANSMITTER

%Source

a = randi([0 1],1,num_bit); % data

 

% Turbo encoder

% component encoder 1

b1 = zeros(1,2*num_bit); % encoder 1 output initialization

b1(1:2:end) = a; % systematic bit

temp1 = mod(conv(gen_poly,a),2); % linear convolution with the generator polynomial

b1(2:2:end) = temp1(1:num_bit); % parity bit

% component encoder 2

b2 = zeros(1,2*num_bit); % encoder 2 output initialization

b2(1:2:end) = a(intr_map); % systematic bit

temp2 = mod(conv(gen_poly,b2(1:2:end)),2); % linear convolution with the generator polynomial

b2(2:2:end) = temp2(1:num_bit); % parity bit

% QPSK mapping (according to the set partitioning principles)
mod_sig1 = 1-2*b1(1:2:end) + 1i*(1-2*b1(2:2:end));
mod_sig2 = 1-2*b2(1:2:end) + 1i*(1-2*b2(2:2:end));
mod_sig = [mod_sig1 mod_sig2];

%--------------------------------------------------------------------------
%                            CHANNEL   
% AWGN
white_noise = sqrt(noise_var_1D)*randn(1,frame_size)+1i*sqrt(noise_var_1D)*randn(1,frame_size); 
Chan_Op = mod_sig + white_noise; % Chan_Op stands for channel output

SNR_dB1 = 1; % SNR per bit in dB (in logarithmic scale)
SNR1 = 10^(0.1*SNR_dB1); % SNR per bit in linear scale
noise_var_1D1 = 2*2/(2*SNR1); % 1D noise variance
white_noise1 = sqrt(noise_var_1D1)*randn(1,frame_size)+1i*sqrt(noise_var_1D1)*randn(1,frame_size); 
Chan_Op1 =  mod_sig + white_noise1;

SNR_dB2 = 1.5; % SNR per bit in dB (in logarithmic scale)
SNR2 = 10^(0.1*SNR_dB2); % SNR per bit in linear scale
noise_var_1D2 = 2*2/(2*SNR2); % 1D noise variance
white_noise2 = sqrt(noise_var_1D2)*randn(1,frame_size)+1i*sqrt(noise_var_1D2)*randn(1,frame_size); 
Chan_Op2 = mod_sig + white_noise2;

SNR_dB3 = 2; % SNR per bit in dB (in logarithmic scale)
SNR3 = 10^(0.1*SNR_dB3); % SNR per bit in linear scale
noise_var_1D3 = 2*2/(2*SNR3); % 1D noise variance
white_noise3 = sqrt(noise_var_1D3)*randn(1,frame_size)+1i*sqrt(noise_var_1D3)*randn(1,frame_size); 
Chan_Op3 = mod_sig + white_noise3;

SNR_dB4 = 2.5; % SNR per bit in dB (in logarithmic scale)
SNR4 = 10^(0.1*SNR_dB4); % SNR per bit in linear scale
noise_var_1D4 = 2*2/(2*SNR4); % 1D noise variance
white_noise4 = sqrt(noise_var_1D4)*randn(1,frame_size)+1i*sqrt(noise_var_1D4)*randn(1,frame_size); 
Chan_Op4 = mod_sig + white_noise4;

SNR_dB5 = 3; % SNR per bit in dB (in logarithmic scale)
SNR5 = 10^(0.1*SNR_dB5); % SNR per bit in linear scale
noise_var_1D5 = 2*2/(2*SNR5); % 1D noise variance
white_noise5 = sqrt(noise_var_1D5)*randn(1,frame_size)+1i*sqrt(noise_var_1D5)*randn(1,frame_size); 
Chan_Op5 = mod_sig + white_noise5;

SNR_dB6 = 3.5; % SNR per bit in dB (in logarithmic scale)
SNR6 = 10^(0.1*SNR_dB6); % SNR per bit in linear scale
noise_var_1D6 = 2*2/(2*SNR6); % 1D noise variance
white_noise6 = sqrt(noise_var_1D6)*randn(1,frame_size)+1i*sqrt(noise_var_1D6)*randn(1,frame_size); 
Chan_Op6 = mod_sig + white_noise6;

%--------------------------------------------------------------------------
%                          RECEIVER 
% Branch metrices for the BCJR
QPSK_SYM = zeros(4,frame_size);
QPSK_SYM(1,:) = (1+1i)*ones(1,frame_size);
QPSK_SYM(2,:) = (1-1i)*ones(1,frame_size);
QPSK_SYM(3,:) = (-1+1i)*ones(1,frame_size);
QPSK_SYM(4,:) = (-1-1i)*ones(1,frame_size);

Dist = zeros(4,frame_size);
 Dist(1,:)=abs(Chan_Op-QPSK_SYM(1,:)).^2;
 Dist(2,:)=abs(Chan_Op-QPSK_SYM(2,:)).^2;
 Dist(3,:)=abs(Chan_Op-QPSK_SYM(3,:)).^2;
 Dist(4,:)=abs(Chan_Op-QPSK_SYM(4,:)).^2;
 log_gamma = -Dist/(2*noise_var_1D);

 Dist1 = zeros(4,frame_size);
 Dist1(1,:)=abs(Chan_Op1-QPSK_SYM(1,:)).^2;
 Dist1(2,:)=abs(Chan_Op1-QPSK_SYM(2,:)).^2;
 Dist1(3,:)=abs(Chan_Op1-QPSK_SYM(3,:)).^2;
 Dist1(4,:)=abs(Chan_Op1-QPSK_SYM(4,:)).^2;
 log_gamma_1 = -Dist1/(2*noise_var_1D1);

   Dist2 = zeros(4,frame_size);
  Dist2(1,:)=abs(Chan_Op2-QPSK_SYM(1,:)).^2;
  Dist2(2,:)=abs(Chan_Op2-QPSK_SYM(2,:)).^2;
  Dist2(3,:)=abs(Chan_Op2-QPSK_SYM(3,:)).^2;
  Dist2(4,:)=abs(Chan_Op2-QPSK_SYM(4,:)).^2;
  log_gamma_2 = -Dist2/(2*noise_var_1D2);
 
    Dist3 = zeros(4,frame_size);
 Dist3(1,:)=abs(Chan_Op3-QPSK_SYM(1,:)).^2;
 Dist3(2,:)=abs(Chan_Op3-QPSK_SYM(2,:)).^2;
 Dist3(3,:)=abs(Chan_Op3-QPSK_SYM(3,:)).^2;
 Dist3(4,:)=abs(Chan_Op3-QPSK_SYM(4,:)).^2;
 log_gamma_3 = -Dist3/(2*noise_var_1D3);
 
    Dist4 = zeros(4,frame_size);
  Dist4(1,:)=abs(Chan_Op4-QPSK_SYM(1,:)).^2;
   Dist4(2,:)=abs(Chan_Op4-QPSK_SYM(2,:)).^2;
  Dist4(3,:)=abs(Chan_Op4-QPSK_SYM(3,:)).^2;
   Dist4(4,:)=abs(Chan_Op4-QPSK_SYM(4,:)).^2;
   log_gamma_4 = -Dist4/(2*noise_var_1D4);
 
    Dist5 = zeros(4,frame_size);
  Dist5(1,:)=abs(Chan_Op5-QPSK_SYM(1,:)).^2;
  Dist5(2,:)=abs(Chan_Op5-QPSK_SYM(2,:)).^2;
  Dist5(3,:)=abs(Chan_Op5-QPSK_SYM(3,:)).^2;
  Dist5(4,:)=abs(Chan_Op5-QPSK_SYM(4,:)).^2;
  log_gamma_5 = -Dist5/(2*noise_var_1D5);
 
    Dist6 = zeros(4,frame_size);
  Dist6(1,:)=abs(Chan_Op6-QPSK_SYM(1,:)).^2;
  Dist6(2,:)=abs(Chan_Op6-QPSK_SYM(2,:)).^2;
  Dist6(3,:)=abs(Chan_Op6-QPSK_SYM(3,:)).^2;
  Dist6(4,:)=abs(Chan_Op6-QPSK_SYM(4,:)).^2;
  log_gamma_6 = -Dist6/(2*noise_var_1D6); 

log_gamma1 = log_gamma(:,1:num_bit); % branch metrices for component decoder 1
log_gamma2 = log_gamma(:,num_bit+1:end); % branch metrices for component decoder 2

 log_gamma1_1 = log_gamma_1(:,1:num_bit);
 log_gamma2_1 = log_gamma_1(:,num_bit+1:end);

  log_gamma1_2 = log_gamma_2(:,1:num_bit);
  log_gamma2_2 = log_gamma_2(:,num_bit+1:end);
 
  log_gamma1_3 = log_gamma_3(:,1:num_bit);
  log_gamma2_3 = log_gamma_3(:,num_bit+1:end);

  log_gamma1_4 = log_gamma_4(:,1:num_bit);
  log_gamma2_4 = log_gamma_4(:,num_bit+1:end);
 
  log_gamma1_5 = log_gamma_5(:,1:num_bit);
  log_gamma2_5 = log_gamma_5(:,num_bit+1:end);
 
  log_gamma1_6 = log_gamma_6(:,1:num_bit);
 log_gamma2_6 = log_gamma_6(:,num_bit+1:end);

% a priori LLR for component decoder 1 for 1st iteration
LLR = zeros(1,num_bit);
LLR1 = zeros(1,num_bit);
LLR2 = zeros(1,num_bit);
LLR3 = zeros(1,num_bit);
LLR4 = zeros(1,num_bit);
LLR5 = zeros(1,num_bit); 
LLR6 = zeros(1,num_bit);

% iterative logMAP decoding
LLR = log_BCJR(LLR,log_gamma1,num_bit); % outputs extrinsic information
LLR = log_BCJR(LLR(intr_map),log_gamma2,num_bit); %1

LLR = log_BCJR(LLR(deintr_map),log_gamma1,num_bit);
LLR = log_BCJR(LLR(intr_map),log_gamma2,num_bit); %2

LLR = log_BCJR(LLR(deintr_map),log_gamma1,num_bit);
LLR = log_BCJR(LLR(intr_map),log_gamma2,num_bit); %3

LLR = log_BCJR(LLR(deintr_map),log_gamma1,num_bit);
LLR = log_BCJR(LLR(intr_map),log_gamma2,num_bit); %4

 LLR = log_BCJR(LLR(deintr_map),log_gamma1,num_bit);
 LLR = log_BCJR(LLR(intr_map),log_gamma2,num_bit); %5
 
 LLR = log_BCJR(LLR(deintr_map),log_gamma1,num_bit);
 LLR = log_BCJR(LLR(intr_map),log_gamma2,num_bit); %6

LLR1 = log_BCJR(LLR1,log_gamma1_1,num_bit); % outputs extrinsic information
LLR1 = log_BCJR(LLR1(intr_map),log_gamma2_1,num_bit); %1

LLR1 = log_BCJR(LLR1(deintr_map),log_gamma1_1,num_bit);
LLR1 = log_BCJR(LLR1(intr_map),log_gamma2_1,num_bit); %2

LLR1 = log_BCJR(LLR1(deintr_map),log_gamma1_1,num_bit);
LLR1 = log_BCJR(LLR1(intr_map),log_gamma2_1,num_bit); %3

LLR1 = log_BCJR(LLR1(deintr_map),log_gamma1_1,num_bit);
LLR1 = log_BCJR(LLR1(intr_map),log_gamma2_1,num_bit); %4
 
 LLR1 = log_BCJR(LLR1(deintr_map),log_gamma1_1,num_bit);
 LLR1 = log_BCJR(LLR1(intr_map),log_gamma2_1,num_bit); %5
 
 LLR1 = log_BCJR(LLR1(deintr_map),log_gamma1_1,num_bit);
 LLR1 = log_BCJR(LLR1(intr_map),log_gamma2_1,num_bit); %6

 LLR2 = log_BCJR(LLR2,log_gamma1_2,num_bit); % outputs extrinsic information
 LLR2 = log_BCJR(LLR2(intr_map),log_gamma2_2,num_bit); %1
 
 LLR2 = log_BCJR(LLR2(deintr_map),log_gamma1_2,num_bit);
 LLR2 = log_BCJR(LLR2(intr_map),log_gamma2_2,num_bit); %2
 
 LLR2 = log_BCJR(LLR2(deintr_map),log_gamma1_2,num_bit);
 LLR2 = log_BCJR(LLR2(intr_map),log_gamma2_2,num_bit); %3
  
 LLR2 = log_BCJR(LLR2(deintr_map),log_gamma1_2,num_bit);
 LLR2 = log_BCJR(LLR2(intr_map),log_gamma2_2,num_bit); %4
 
  LLR2 = log_BCJR(LLR2(deintr_map),log_gamma1_2,num_bit);
  LLR2 = log_BCJR(LLR2(intr_map),log_gamma2_2,num_bit); %5
  
  LLR2 = log_BCJR(LLR2(deintr_map),log_gamma1_2,num_bit);
  LLR2 = log_BCJR(LLR2(intr_map),log_gamma2_2,num_bit); %6

 LLR3 = log_BCJR(LLR3,log_gamma1_3,num_bit); % outputs extrinsic information
 LLR3 = log_BCJR(LLR3(intr_map),log_gamma2_3,num_bit); %1
 
 LLR3 = log_BCJR(LLR3(deintr_map),log_gamma1_3,num_bit);
 LLR3 = log_BCJR(LLR3(intr_map),log_gamma2_3,num_bit); %2
  
 LLR3 = log_BCJR(LLR3(deintr_map),log_gamma1_3,num_bit);
 LLR3 = log_BCJR(LLR3(intr_map),log_gamma2_3,num_bit); %3
 
 LLR3 = log_BCJR(LLR3(deintr_map),log_gamma1_3,num_bit);
 LLR3 = log_BCJR(LLR3(intr_map),log_gamma2_3,num_bit); %4
 
 LLR3 = log_BCJR(LLR3(deintr_map),log_gamma1_3,num_bit);
  LLR3 = log_BCJR(LLR3(intr_map),log_gamma2_3,num_bit); %5
  
  LLR3 = log_BCJR(LLR3(deintr_map),log_gamma1_3,num_bit);
  LLR3 = log_BCJR(LLR3(intr_map),log_gamma2_3,num_bit); %6

 LLR4 = log_BCJR(LLR4,log_gamma1_4,num_bit); % outputs extrinsic information
 LLR4 = log_BCJR(LLR4(intr_map),log_gamma2_4,num_bit); %1
 
 LLR4 = log_BCJR(LLR4(deintr_map),log_gamma1_4,num_bit);
 LLR4 = log_BCJR(LLR4(intr_map),log_gamma2_4,num_bit); %2
 
 LLR4 = log_BCJR(LLR4(deintr_map),log_gamma1_4,num_bit);
 LLR4 = log_BCJR(LLR4(intr_map),log_gamma2_4,num_bit); %3
 
 LLR4 = log_BCJR(LLR4(deintr_map),log_gamma1_4,num_bit);
 LLR4 = log_BCJR(LLR4(intr_map),log_gamma2_4,num_bit); %4
  
  LLR4 = log_BCJR(LLR4(deintr_map),log_gamma1_4,num_bit);
  LLR4 = log_BCJR(LLR4(intr_map),log_gamma2_4,num_bit); %5
  
  LLR4 = log_BCJR(LLR4(deintr_map),log_gamma1_4,num_bit);
  LLR4 = log_BCJR(LLR4(intr_map),log_gamma2_4,num_bit); %6

 LLR5 = log_BCJR(LLR5,log_gamma1_5,num_bit); % outputs extrinsic information
 LLR5 = log_BCJR(LLR5(intr_map),log_gamma2_5,num_bit); %1
 
 LLR5 = log_BCJR(LLR5(deintr_map),log_gamma1_5,num_bit);
 LLR5 = log_BCJR(LLR5(intr_map),log_gamma2_5,num_bit); %2
 
 LLR5 = log_BCJR(LLR5(deintr_map),log_gamma1_5,num_bit);
 LLR5 = log_BCJR(LLR5(intr_map),log_gamma2_5,num_bit); %3
 
 LLR5 = log_BCJR(LLR5(deintr_map),log_gamma1_5,num_bit);
 LLR5 = log_BCJR(LLR5(intr_map),log_gamma2_5,num_bit); %4
 
  LLR5 = log_BCJR(LLR5(deintr_map),log_gamma1_5,num_bit);
  LLR5 = log_BCJR(LLR5(intr_map),log_gamma2_5,num_bit); %5
  
  LLR5 = log_BCJR(LLR5(deintr_map),log_gamma1_5,num_bit);
  LLR5 = log_BCJR(LLR5(intr_map),log_gamma2_5,num_bit); %6
  
 LLR6 = log_BCJR(LLR6,log_gamma1_6,num_bit); % outputs extrinsic information
 LLR6 = log_BCJR(LLR6(intr_map),log_gamma2_6,num_bit); %1
 
 LLR6 = log_BCJR(LLR6(deintr_map),log_gamma1_6,num_bit);
 LLR6 = log_BCJR(LLR6(intr_map),log_gamma2_6,num_bit); %2
 
 LLR6 = log_BCJR(LLR6(deintr_map),log_gamma1_6,num_bit);
 LLR6 = log_BCJR(LLR6(intr_map),log_gamma2_6,num_bit); %3
 
 LLR6 = log_BCJR(LLR6(deintr_map),log_gamma1_6,num_bit);
 LLR6 = log_BCJR(LLR6(intr_map),log_gamma2_6,num_bit); %4
  
  LLR6 = log_BCJR(LLR6(deintr_map),log_gamma1_6,num_bit);
  LLR6 = log_BCJR(LLR6(intr_map),log_gamma2_6,num_bit); %5
  
  LLR6 = log_BCJR(LLR6(deintr_map),log_gamma1_6,num_bit);
  LLR6 = log_BCJR(LLR6(intr_map),log_gamma2_6,num_bit); %6
 
 % hard decision 
LLR = LLR(deintr_map);
dec_data = LLR<0;

LLR1 = LLR1(deintr_map);
dec_data1 = LLR1<0;

 LLR2 = LLR2(deintr_map);
 dec_data2 = LLR2<0;
 
 LLR3 = LLR3(deintr_map);
 dec_data3 = LLR3<0;
 
 LLR4 = LLR4(deintr_map);
 dec_data4 = LLR4<0;
 
 LLR5 = LLR5(deintr_map);
 dec_data5 = LLR5<0;
 
 LLR6 = LLR6(deintr_map);
 dec_data6 = LLR6<0;

 % Calculating total bit errors
C_Ber = C_Ber + nnz(dec_data-a);  
C_Ber1 = C_Ber1 + nnz(dec_data1-a); 
 C_Ber2 = C_Ber2 + nnz(dec_data2-a);
 C_Ber3 = C_Ber3 + nnz(dec_data3-a); 
 C_Ber4 = C_Ber4 + nnz(dec_data4-a);
 C_Ber5 = C_Ber5 + nnz(dec_data5-a);
 C_Ber6 = C_Ber6 + nnz(dec_data6-a);
count = frame_cnt

end

BER = C_Ber/(frame_cnt*num_bit);
BER1 = C_Ber1/(frame_cnt*num_bit);
BER2 = C_Ber2/(frame_cnt*num_bit);
 BER3 = C_Ber3/(frame_cnt*num_bit);
 BER4 = C_Ber4/(frame_cnt*num_bit);
 BER5 = C_Ber5/(frame_cnt*num_bit);
 BER6 = C_Ber6/(frame_cnt*num_bit);
 
BER_total = zeros(1,7);
BER_total(1) = BER;
BER_total(2) =BER1;
BER_total(3) =BER2;
 BER_total(4) =BER3;
 BER_total(5) =BER4;
 BER_total(6) =BER5;
 BER_total(7) =BER6;

t = 1:1:7;
semilogy(t,BER_total, '-bo');

xlabel('Eb/N0(dB)');
ylabel('Bit error rate');
title('Performance of Turbo codes based on the BCJR algorithm');
toc() 