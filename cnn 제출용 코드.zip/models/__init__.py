from .resnet import resnet18, resnet50
from .resfcn import resfcn18
from .custom_cnn import CustomCNN