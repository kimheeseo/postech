package com.example.mycalculator;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    // Component variables
    private Button btn0, btn1, btn2, btn3, btn4, btn5;
    private Button btn6, btn7, btn8, btn9, btn_equal;
    private Button btn_div, btn_mul, btn_minus, btn_plus, btn_dot;
    private TextView tv_log;
    private String log_stack = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setTitle("김희서(float)의 계산기 과제 20212245");

        tv_log = (TextView) findViewById(R.id.tv_log);
        Button.OnClickListener myClickListener = new Button.OnClickListener(){
            // Button 클릭시 실행할 코드를 정의
            // Button class의 OnClickListener class를 생성하고 버튼 클릭시 할 동작을 "override" 합니다.
            @Override
            public void onClick(View v) {
                switch (v.getId()){
                    case R.id.btn0:      log_stack += "0"; break;
                    case R.id.btn1:      log_stack += "1"; break; // 이렇게 한 줄로 쓸 수 도 있습니다.
                    case R.id.btn2:      log_stack += "2"; break; // 반복적인 구조의 경우 한 줄로 쓰면
                    case R.id.btn3:      log_stack += "3"; break; // 가독성이 좋아집니다.
                    case R.id.btn4:      log_stack += "4"; break;
                    case R.id.btn5:      log_stack += "5"; break;
                    case R.id.btn6:      log_stack += "6"; break;
                    case R.id.btn7:      log_stack += "7"; break;
                    case R.id.btn8:      log_stack += "8"; break;
                    case R.id.btn9:      log_stack += "9"; break;

                    case R.id.btn_plus:  log_stack += "+"; break;
                    case R.id.btn_minus:  log_stack += "-"; break;
                    case R.id.btn_mul:  log_stack += "*"; break;
                    case R.id.btn_div:  log_stack += "/"; break;

                    case R.id.btn_dot:  log_stack += "."; break;
                    case R.id.btn_equal:
                        // '=' button: log_stack에 쌓은 sequence를 process_calculator 함수에서 처리합니다.
                        log_stack += "=";
                        log_stack = process_calculator(log_stack);
                        tv_log.setText(log_stack);
                        log_stack = "";
                        return; // 결과를 출력한 다음 log_stack을 비우고 끝낸다.
                }
                tv_log.setText(log_stack); // log_stack의 내용을 스마트폰 화면에 출력한다.
            }
        };

        // [[ Button, TextView Class와 컴포넌트를 연결 ]]
        // class를 통해서 만들어낸 객체를 class에서 상속받은 findViewById 함수를 사용하여
        // R.id.* 라는 activity_main.xml에서 설정한 layout component와 연결한다.
        btn0 = (Button) findViewById(R.id.btn0);
        btn1 = (Button) findViewById(R.id.btn1);
        btn2 = (Button) findViewById(R.id.btn2);
        btn3 = (Button) findViewById(R.id.btn3);
        btn4 = (Button) findViewById(R.id.btn4);
        btn5 = (Button) findViewById(R.id.btn5);
        btn6 = (Button) findViewById(R.id.btn6);
        btn7 = (Button) findViewById(R.id.btn7);
        btn8 = (Button) findViewById(R.id.btn8);
        btn9 = (Button) findViewById(R.id.btn9);
        btn_plus = (Button) findViewById(R.id.btn_plus);
        btn_minus = (Button) findViewById(R.id.btn_minus);
        btn_mul = (Button) findViewById(R.id.btn_mul);
        btn_div = (Button) findViewById(R.id.btn_div);

        btn_equal = (Button) findViewById(R.id.btn_equal);
        btn_dot = (Button) findViewById(R.id.btn_dot);

        // [[ Button, TextView Class와 custom ClickListener를 연결 ]]
        // class를 통해서 만들어낸 객체를 class에서 상속받은 setOnClickListener 함수를 사용하여
        // myClickListener라는 이 MainActivity.java에서 직접 정의한 custom ClickListener와 연결한다.
        btn0.setOnClickListener(myClickListener);
        btn1.setOnClickListener(myClickListener);
        btn2.setOnClickListener(myClickListener);
        btn3.setOnClickListener(myClickListener);
        btn4.setOnClickListener(myClickListener);
        btn5.setOnClickListener(myClickListener);
        btn6.setOnClickListener(myClickListener);
        btn7.setOnClickListener(myClickListener);
        btn8.setOnClickListener(myClickListener);
        btn9.setOnClickListener(myClickListener);

        btn_plus.setOnClickListener(myClickListener);
        btn_minus.setOnClickListener(myClickListener);
        btn_mul.setOnClickListener(myClickListener);
        btn_div.setOnClickListener(myClickListener);
        btn_dot.setOnClickListener(myClickListener);
        btn_equal.setOnClickListener(myClickListener);
    } // End of onCreate

    String process_calculator(String in_str){
        // Log.d를 사용하면 스마트폰에서 앱 실행 시 in_str를 Logcat에서 볼 수 있습니다. (설치 매뉴얼에 위치 설명 있음)
        Log.d("User","in_str: "+in_str);

        // 변수
        float nums [] = new float [2]; // 지금 연산자 바로 앞의 숫자;
        int cnt = 0; // nums의 갯수를 count
        String num_stack = ""; // 여러자리 숫자와 이전 연산자를 저장합니다.
        String ops = "initial"; // operation 저장

        for (int i = 0 ; i < in_str.length(); i ++){
            String cur = in_str.substring(i,i+1);
            switch(cur){ // cur을 숫자 혹은 연산자로 바꾸는 곳 입니다.
                //--------------------------------------------------------------------------------//
                case "+":
                case "-":
                case "*":
                case "/":
                    ops = cur; // 연산자를 저장합니다.
                case "=":
                    nums[cnt] = Float.parseFloat(num_stack); // 지금 연산자 바로 앞의 숫자
                    num_stack = ""; // num_stack를 사용했기 때문에 비워줍니다.
                    cnt++; // cnt 값 1 증가
                    break;
                //--------------------------------------------------------------------------------//
                case "0":
                case "1":
                case "2":
                case "3":
                case "4":
                case "5":
                case "6":
                case "7":
                case "8":
                case "9":
                case ".":
                    num_stack += cur; // 여러자리 숫자일 수 있기 때문에 num_stack에 쌓습니다.
                    break;
            } // End of switch
        } // End of for loop

        float calc_result = 0; // 계산결과가 저장됩니다.
        switch (ops) { // 저장된 연산자를 보고 입력된 nums[0]와 nums[1]을 계산합니다.
            case "initial": // 입력된 연산자없이 =를 눌렀습니다.
                calc_result = nums[0];
                break;
            case "+":
                calc_result = nums[0]+nums[1];
                break;
            case "-":
                calc_result = nums[0]-nums[1];
                break;
            case "*":
                calc_result = nums[0]*nums[1];
                break;
            case "/":
                calc_result = nums[0]/nums[1];
                break;
        }
        in_str += "\n" + calc_result; // \n은 new_line을 의미합니다.
        return in_str;
    } // End of process_calculator function

} // End of MainActivity class