﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.IO.Ports;
using System.Threading;

namespace USBAccess
{
    public partial class Form1 : Form
    {
        // Constants
        public const int REC_BUFFER_SIZE = 500;
        public const int READ_TIMEOUT = 500;
        public const int WRITE_TIMEOUT = 500;
        public const int REC_BUFFER_FILLTIME = 80;

        public static SerialPort _serialport;

        public Form1()
        {
            InitializeComponent();

            string[] sPorts = new string[20];
            sPorts = SerialPort.GetPortNames();

            for (int nIndex = 0; nIndex < sPorts.Length; nIndex++)
                cboCOMPort.Items.Add(sPorts[nIndex]);

        }// end Form1

        // SetTextDeleg
        // ---------------------------------------------------------------------------------
        private delegate void SetTextDeleg(string text);

        // sp_DataReceived
        // ---------------------------------------------------------------------------------
        void sp_DataReceived(object sender, SerialDataReceivedEventArgs e)
        {
            // Set the receive buffer size
            char[] sRecData = new char[REC_BUFFER_SIZE + 1];

            // Give the hardware some time to receive the whole message
            Thread.Sleep(REC_BUFFER_FILLTIME);
            try
            {
                int nBytes = _serialport.BytesToRead;

                // Read the string
                int nIndex;
                for (nIndex = 0; nIndex < nBytes; nIndex++)
                {
                    int nRec = _serialport.ReadByte();
                    sRecData[nIndex] = (char)nRec;
                }// end for
                sRecData[nIndex] = (char)0; // Terminate the string
                string sStr = new string(sRecData);

                //string data = _serialport.ReadLine();
                // In case of RS232, this line causes a timeout, meaning no data is being received
                this.BeginInvoke(new SetTextDeleg(si_DataReceived), new object[] { sStr });
            }
            catch (TimeoutException) { }

        }// end _serialport_DataReceived

        // si_DataReceived
        // ---------------------------------------------------------------------------------
        private void si_DataReceived(string data) 
        {
            if(txtReceived.TextLength == 0)
                txtReceived.Text = data;
            else
                txtReceived.Text += "\n\r" + data;

            txtReceived.SelectionStart = txtReceived.TextLength; // Set cursor to end of screen
            txtReceived.ScrollToCaret();
            txtReceived.Refresh();

        }// end si_DataReceived

        // btnSend_Click
        // ---------------------------------------------------------------------------------
        private void btnSend_Click(object sender, EventArgs e)
        {
            // Make sure the serial port is open before trying to write
            try
            {
                if (!(_serialport.IsOpen)) 
                    _serialport.Open();
                if (txtSend.Text.Length > 0)
                    _serialport.Write(txtSend.Text);
                else
                    MessageBox.Show("Please enter a message to be sent.", "Attention!");

            }
            catch (Exception ex)
            {
                MessageBox.Show("Error opening/writing to serial port." + ex.Message, "Error!");
            }

        }// end btnSend_Click

        //-SUB------------------------------------------------------------------------
        // Event : cboCOMPort_SelectedIndexChanged
        //----------------------------------------------------------------------------
        private void cboCOMPort_SelectedIndexChanged(object sender, EventArgs e)
        {
            // Define the serial port for the USB device
            _serialport = new SerialPort(cboCOMPort.SelectedItem.ToString(), 9600, Parity.None, 8, StopBits.One);
            _serialport.Handshake = Handshake.None;

            // Set the read/write timeouts
            _serialport.ReadTimeout = READ_TIMEOUT;
            _serialport.WriteTimeout = WRITE_TIMEOUT;
            _serialport.ReadBufferSize = REC_BUFFER_SIZE;
            _serialport.Open();

            _serialport.DataReceived += new SerialDataReceivedEventHandler(sp_DataReceived);

        }// end cboCOMPort_SelectedIndexChanged

    }// end class

}// end namespace
